# RLGame

## Description

RLGame is a package provides multi-agent implementation of some classic games for Reinforcement Learning (RL)

## Dependencies

* pip
* numpy
* matplotlib